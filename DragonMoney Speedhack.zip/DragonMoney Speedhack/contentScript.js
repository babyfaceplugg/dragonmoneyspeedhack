// contentScript.js - БЕЗОПАСНАЯ ВЕРСИЯ
console.log('DragonMoney Speedhack content script loading...');

let speedConfig = {
  speed: 1.0,
  cbSetIntervalChecked: true,
  cbSetTimeoutChecked: true,
  cbPerformanceNowChecked: true,
  cbDateNowChecked: true,
  cbRequestAnimationFrameChecked: false,
};

// Безопасный messaging
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  console.log('Content script received:', request);
  
  if (request.command == "setSpeedConfig") {
    speedConfig = request.config;
    // Отправляем в page context безопасно
    window.postMessage({
      command: "setSpeedConfig", 
      config: speedConfig,
      source: 'dragonmoney-extension'
    }, "*");
    sendResponse({success: true});
  } else if (request.command == "getSpeedConfig") {
    sendResponse(speedConfig);
  }
  return true;
});

// Inject page script безопасно
function injectPageScript() {
  const script = document.createElement('script');
  script.src = chrome.runtime.getURL('pageScript.js');
  script.onload = function() {
    this.remove();
  };
  (document.head || document.documentElement).appendChild(script);
}

// Ждем когда DOM готов
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', injectPageScript);
} else {
  injectPageScript();
}

console.log('DragonMoney Speedhack content script loaded');