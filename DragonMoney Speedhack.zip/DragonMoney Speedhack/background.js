// background.js
chrome.runtime.onInstalled.addListener(() => {
  console.log('DragonMoney Speedhack installed and ready!');
});

// Для обработки сообщений от popup, если нужно
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.command === "getSpeedConfig") {
    // Логика для получения конфига
    sendResponse({speed: 1.0});
  }
  return true;
});