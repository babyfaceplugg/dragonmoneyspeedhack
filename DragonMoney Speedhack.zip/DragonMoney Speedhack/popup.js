// popup.js
class SpeedhackPopup {
    constructor() {
        this.speedConfig = {
            speed: 1.0,
            cbSetIntervalChecked: true,
            cbSetTimeoutChecked: true,
            cbPerformanceNowChecked: true,
            cbDateNowChecked: true,
            cbRequestAnimationFrameChecked: false,
        };
        
        this.applyTimeout = null;
        this.isAccordionOpen = false;
        this.init();
    }

    init() {
        console.log('DragonMoney Speedhack popup initialized');
        this.bindElements();
        this.bindEvents();
        this.loadConfig();
    }

    bindElements() {
        this.elements = {
            speedSlider: document.getElementById('speedSlider'),
            speedValue: document.getElementById('speedValue'),
            resetBtn: document.getElementById('resetBtn'),
            maxBtn: document.getElementById('maxBtn'),
            setIntervalCheck: document.getElementById('setIntervalCheckBox'),
            setTimeoutCheck: document.getElementById('setTimeoutCheckBox'),
            performanceCheck: document.getElementById('performanceCheckBox'),
            dateCheck: document.getElementById('dateCheckBox'),
            animationCheck: document.getElementById('animationCheckBox'),
            accordionBtn: document.getElementById('accordionBtn'),
            accordionContent: document.getElementById('accordionContent'),
            accordionIcon: document.getElementById('accordionIcon')
        };
    }

    bindEvents() {
        // Слайдер скорости - автоматическое применение
        this.elements.speedSlider.addEventListener('input', (e) => {
            const value = parseFloat(e.target.value).toFixed(1);
            this.elements.speedValue.textContent = value + 'x';
            
            // Автоматически применяем настройки с задержкой
            this.scheduleApply();
        });

        // Чекбоксы - автоматическое применение
        [this.elements.setIntervalCheck, this.elements.setTimeoutCheck, 
         this.elements.performanceCheck, this.elements.dateCheck, 
         this.elements.animationCheck].forEach(checkbox => {
            checkbox.addEventListener('click', () => {
                checkbox.classList.toggle('checked');
                this.scheduleApply();
            });
        });

        // Кнопка сброса до 1.0x
        this.elements.resetBtn.addEventListener('click', () => {
            this.resetToMin();
        });

        // Кнопка установки максимума 20x
        this.elements.maxBtn.addEventListener('click', () => {
            this.setToMax();
        });

        // Аккордеон - открытие/закрытие
        this.elements.accordionBtn.addEventListener('click', () => {
            this.toggleAccordion();
        });
    }

    toggleAccordion() {
        this.isAccordionOpen = !this.isAccordionOpen;
        
        if (this.isAccordionOpen) {
            this.elements.accordionContent.classList.add('open');
            this.elements.accordionIcon.classList.add('open');
        } else {
            this.elements.accordionContent.classList.remove('open');
            this.elements.accordionIcon.classList.remove('open');
        }
    }

    scheduleApply() {
        // Отменяем предыдущий таймер
        if (this.applyTimeout) {
            clearTimeout(this.applyTimeout);
        }
        
        // Устанавливаем новый таймер (применяем через 300ms после последнего изменения)
        this.applyTimeout = setTimeout(() => {
            this.applySettings();
        }, 300);
    }

    resetToMin() {
        this.elements.speedSlider.value = 1.0;
        this.elements.speedValue.textContent = '1.0x';
        this.applySettings();
    }

    setToMax() {
        this.elements.speedSlider.value = 20.0;
        this.elements.speedValue.textContent = '20.0x';
        this.applySettings();
    }

    getCurrentConfig() {
        return {
            speed: parseFloat(this.elements.speedSlider.value),
            cbSetIntervalChecked: this.elements.setIntervalCheck.classList.contains('checked'),
            cbSetTimeoutChecked: this.elements.setTimeoutCheck.classList.contains('checked'),
            cbPerformanceNowChecked: this.elements.performanceCheck.classList.contains('checked'),
            cbDateNowChecked: this.elements.dateCheck.classList.contains('checked'),
            cbRequestAnimationFrameChecked: this.elements.animationCheck.classList.contains('checked')
        };
    }

    applySettings() {
        const config = this.getCurrentConfig();
        console.log('Auto-applying settings:', config);

        // Отправляем настройки в content script
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0] && tabs[0].id) {
                chrome.tabs.sendMessage(tabs[0].id, {
                    command: "setSpeedConfig",
                    config: config
                }, (response) => {
                    if (chrome.runtime.lastError) {
                        console.error('Error applying settings:', chrome.runtime.lastError.message);
                    } else {
                        console.log('Settings auto-applied successfully');
                        this.speedConfig = config;
                    }
                });
            }
        });
    }

    resetSettings() {
        this.resetToMin();
        
        // Включаем все чекбоксы кроме requestAnimationFrame
        this.elements.setIntervalCheck.classList.add('checked');
        this.elements.setTimeoutCheck.classList.add('checked');
        this.elements.performanceCheck.classList.add('checked');
        this.elements.dateCheck.classList.add('checked');
        this.elements.animationCheck.classList.remove('checked');

        // Автоматически применяем сброс
        this.applySettings();
    }

    loadConfig() {
        // Загружаем текущие настройки из content script
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0] && tabs[0].id) {
                chrome.tabs.sendMessage(tabs[0].id, {
                    command: "getSpeedConfig"
                }, (response) => {
                    if (chrome.runtime.lastError) {
                        console.log('Content script not ready:', chrome.runtime.lastError.message);
                        return;
                    }
                    
                    if (response) {
                        console.log('Loaded config:', response);
                        this.updateUI(response);
                        this.speedConfig = response;
                    }
                });
            }
        });
    }

    updateUI(config) {
        this.elements.speedSlider.value = config.speed;
        this.elements.speedValue.textContent = config.speed.toFixed(1) + 'x';

        this.toggleCheckbox(this.elements.setIntervalCheck, config.cbSetIntervalChecked);
        this.toggleCheckbox(this.elements.setTimeoutCheck, config.cbSetTimeoutChecked);
        this.toggleCheckbox(this.elements.performanceCheck, config.cbPerformanceNowChecked);
        this.toggleCheckbox(this.elements.dateCheck, config.cbDateNowChecked);
        this.toggleCheckbox(this.elements.animationCheck, config.cbRequestAnimationFrameChecked);
    }

    toggleCheckbox(element, checked) {
        if (checked) {
            element.classList.add('checked');
        } else {
            element.classList.remove('checked');
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new SpeedhackPopup();
});